class StudyResourceHelper {
    constructor() {
        this.debug = true;
        this.apiKey = null;
        this.loadApiKey();
    }

    async loadApiKey() {
        const result = await chrome.storage.local.get(['geminiApiKey']);
        this.apiKey = result.geminiApiKey;
    }

    log(message) {
        if (this.debug) {
            console.log(`[NTTF ExamBypass] ${message}`);
        }
    }

    init() {
        this.createAnswerPopup();
        this.createSearchButton();
        this.addSelectionStyle();
        this.initMessageListener();
    }

    addSelectionStyle() {
        const style = document.createElement('style');
        style.textContent = `
            ::selection {
                background: transparent !important;
                color: inherit !important;
            }
            ::-moz-selection {
                background: transparent !important;
                color: inherit !important;
            }
        `;
        document.head.appendChild(style);
    }

    createSearchButton() {
        const button = document.createElement('button');
        button.id = 'nttf-exambypass-button';
        button.style.cssText = `
            position: fixed !important;
            bottom: 20px !important;
            left: 20px !important;
            width: 12px !important;
            height: 12px !important;
            background: #808080 !important;  /* Changed from #2196F3 to grey */
            color: white !important;
            border: none !important;
            border-radius: 50% !important;
            cursor: pointer !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            z-index: 2147483647 !important;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2) !important;
            opacity: 0.7 !important;
            transition: all 0.2s !important;
            padding: 0 !important;
            min-width: 0 !important;
            min-height: 0 !important;
            outline: none !important;
        `;

        button.onmouseover = () => {
            button.style.transform = 'scale(1.5)';
            button.style.opacity = '1';
        };
        button.onmouseout = () => {
            button.style.transform = 'scale(1)';
            button.style.opacity = '0.7';
        };

        button.onclick = async () => {
            const selection = window.getSelection();
            const selectedText = selection.toString().trim();
            
            if (selectedText) {
                this.showPopup('Wait...');
                const formattedText = this.formatQuestionText(selectedText);
                const answer = await this.getAnswerFromGemini(formattedText);
                this.showPopup(answer, 1300);  // Changed from 1200 to 1300
            } else {
                this.showPopup('Please select question text first');
            }
        };

        document.body.appendChild(button);
    }

    createAnswerPopup() {
        const popup = document.createElement('div');
        popup.id = 'nttf-exambypass-popup';
        popup.style.cssText = `
            position: fixed !important;
            bottom: 20px !important;
            left: 70px !important;
            background: white !important;
            padding: 10px !important;
            border-radius: 4px !important;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2) !important;
            display: none;
            z-index: 2147483647 !important;
            font-family: Arial, sans-serif !important;
            font-size: 14px !important;
            min-width: 50px !important;
            text-align: center !important;
        `;

        document.body.appendChild(popup);
    }

    formatQuestionText(text) {
        // Split text into lines and clean each line
        const lines = text.split(/[\n\r]+/)
            .map(line => line.trim())
            .filter(line => line.length > 0);

        // Get the question (all lines before options) and join with spaces
        const questionLines = [];
        const optionLines = [];
        let foundOptions = false;

        for (const line of lines) {
            // Check if line starts with a), b), c), d) or A), B), C), D)
            if (line.match(/^[a-dA-D]\s*\)/)) {
                foundOptions = true;
            }
            
            if (foundOptions) {
                optionLines.push(line);
            } else {
                questionLines.push(line);
            }
        }

        // Join question lines with space
        const question = questionLines.join(' ').replace(/\s+/g, ' ').trim();
        
        // Format the output
        return `
Question: ${question}
Options:
${optionLines.map((line, i) => `${String.fromCharCode(97 + i)}) ${line.replace(/^[a-dA-D]\s*\)\s*/, '')}`).join('\n')}
        `.trim();
    }

    async getAnswerFromGemini(text) {
        if (!this.apiKey) {
            this.showPopup('Please set API key in extension popup', 3000);
            return null;
        }

        const sourceFile = (await chrome.storage.local.get(['sourceFile'])).sourceFile;
        
        const prompt = `Indistrial Drive E3/M3
MCQ QUESTION ANSWER SOURCE:

the format is like = QUESTION:ANSWER

${sourceFile}

answer this question from above source (respond with Answer:{answer} format):${text}, if user prove options then answer the question with option no ex A:management, and if the source ans has green dot display it too `;

        const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${this.apiKey}`;

        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [{ text: prompt }]
                }],
                generationConfig: {
                    maxOutputTokens: 20,
                    temperature: 2
                }
            })
        });

        if (!response.ok) throw new Error('API request failed');
        
        const data = await response.json();
        const fullResponse = data.candidates[0].content.parts[0].text.trim();
        
        // Extract text after "Answer:" or "answer:"
        const match = fullResponse.match(/(?:Answer|answer):\s*(.+)/i);
        return match ? match[1].trim() : fullResponse;
    }

    showPopup(text, duration = 3000) {
        const popup = document.getElementById('nttf-exambypass-popup');
        if (popup) {
            // Update styles to accommodate emoji
            popup.style.fontSize = '16px';
            popup.textContent = text;
            popup.style.display = 'block';
            if (duration > 0) {
                setTimeout(() => {
                    popup.style.display = 'none';
                }, duration);
            }
        }
    }

    initMessageListener() {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            try {
                if (message.action === 'updateApiKey') {
                    this.apiKey = message.apiKey;
                    sendResponse({ status: 'success' });
                }
                else if (message.action === 'updateSettings') {
                    const settings = message.settings;
                    
                    // Handle each setting individually
                    if ('allowCopy' in settings) {
                        if (settings.allowCopy) {
                            this.enableCopyText();
                        }
                    }
                    
                    if ('alwaysActive' in settings) {
                        if (settings.alwaysActive) {
                            this.enableAlwaysActive();
                        }
                    }
                    
                    if ('allowRightClick' in settings) {
                        if (settings.allowRightClick) {
                            this.enableRightClick();
                        }
                    }
                    
                    // Save settings to storage
                    chrome.storage.local.set(settings);
                    sendResponse({ status: 'success' });
                }
            } catch (error) {
                console.error('Error handling message:', error);
                sendResponse({ status: 'error', message: error.message });
            }
            
            return true; // Keep the message channel open
        });
    }

    enableCopyText() {
        const style = document.createElement('style');
        style.textContent = `
            * {
                user-select: text !important;
                -webkit-user-select: text !important;
                -moz-user-select: text !important;
                -ms-user-select: text !important;
            }
        `;
        document.head.appendChild(style);
        
        // Remove copy protection
        document.oncopy = null;
        document.oncut = null;
        document.onpaste = null;
        document.onselectstart = null;
        document.oncontextmenu = null;
        document.onmousedown = null;
    }

    enableAlwaysActive() {
        // Override visibility change
        document.addEventListener('visibilitychange', (e) => {
            e.stopImmediatePropagation();
            e.preventDefault();
        }, true);

        // Override blur events
        window.addEventListener('blur', (e) => {
            e.stopImmediatePropagation();
            e.preventDefault();
        }, true);

        // Set visibility state
        Object.defineProperty(document, 'hidden', { 
            value: false,
            writable: false 
        });
        Object.defineProperty(document, 'visibilityState', { 
            value: 'visible',
            writable: false 
        });
    }

    enableRightClick() {
        // Remove existing handlers
        document.oncontextmenu = null;
        document.onmousedown = null;
        document.onmouseup = null;
        
        // Add our handlers
        document.addEventListener('contextmenu', (e) => {
            e.stopImmediatePropagation();
            return true;
        }, true);

        document.addEventListener('mousedown', (e) => {
            if (e.button === 2) {
                e.stopImmediatePropagation();
                return true;
            }
        }, true);
    }
}

// Initialize when document is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        const helper = new StudyResourceHelper();
        helper.init();
    });
} else {
    const helper = new StudyResourceHelper();
    helper.init();
}