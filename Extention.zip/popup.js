document.addEventListener('DOMContentLoaded', async () => {
    const apiSection = document.getElementById('apiSection');
    const featuresSection = document.getElementById('featuresSection');
    
    // Load saved API key and settings
    const savedData = await chrome.storage.local.get(['geminiApiKey', 'allowCopy', 'alwaysActive', 'allowRightClick']);
    
    if (savedData.geminiApiKey) {
        // Hide API input and show features
        apiSection.style.display = 'none';
        featuresSection.style.display = 'block';
        
        // Set checkbox states
        document.getElementById('allowCopy').checked = Boolean(savedData.allowCopy);
        document.getElementById('alwaysActive').checked = Boolean(savedData.alwaysActive);
        document.getElementById('allowRightClick').checked = Boolean(savedData.allowRightClick);
    } else {
        // Show API input and hide features
        apiSection.style.display = 'block';
        featuresSection.style.display = 'none';
    }

    const savedSource = await chrome.storage.local.get(['sourceFile']);
    if (savedSource.sourceFile) {
        document.getElementById('sourceFile').value = savedSource.sourceFile;
    }

    document.getElementById('saveSource').addEventListener('click', async () => {
        const sourceContent = document.getElementById('sourceFile').value.trim();
        await chrome.storage.local.set({ sourceFile: sourceContent });
        showFeedback('Source file saved!', 'success');
    });

    document.getElementById('clearSource').addEventListener('click', async () => {
        await chrome.storage.local.remove('sourceFile');
        document.getElementById('sourceFile').value = '';
        showFeedback('Source file cleared!', 'success');
    });

    // Handle save API key
    document.getElementById('saveApiKey').addEventListener('click', async () => {
        const apiKey = document.getElementById('apiKey').value.trim();
        
        if (!apiKey) {
            showFeedback('Please enter an API key', 'error');
            return;
        }

        try {
            await chrome.storage.local.set({ geminiApiKey: apiKey });
            
            // Show features section
            apiSection.style.display = 'none';
            featuresSection.style.display = 'block';
            
            showFeedback('API Key saved successfully!', 'success');

            // Reload the page to apply changes
            chrome.tabs.reload();
        } catch (error) {
            console.error('Error saving API key:', error);
            showFeedback('Error saving API key', 'error');
        }
    });

    // Handle change API key button
    document.getElementById('changeApiKey').addEventListener('click', () => {
        apiSection.style.display = 'block';
        featuresSection.style.display = 'none';
    });

    // Handle feature toggles
    ['allowCopy', 'alwaysActive', 'allowRightClick'].forEach(feature => {
        document.getElementById(feature).addEventListener('change', async (e) => {
            try {
                // Save to storage
                await chrome.storage.local.set({
                    [feature]: e.target.checked
                });
                
                // Reload the current tab to apply changes
                const tabs = await chrome.tabs.query({active: true, currentWindow: true});
                if (tabs[0]) {
                    chrome.tabs.reload(tabs[0].id);
                }
                
                showFeedback('Settings saved!', 'success');
            } catch (error) {
                console.error('Error saving settings:', error);
                showFeedback('Error saving settings', 'error');
            }
        });
    });
});

function showFeedback(message, type = 'success') {
    const feedback = document.createElement('div');
    feedback.style.cssText = `
        position: fixed;
        bottom: 10px;
        left: 50%;
        transform: translateX(-50%);
        background: ${type === 'success' ? '#4CAF50' : '#f44336'};
        color: white;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 12px;
    `;
    feedback.textContent = message;
    document.body.appendChild(feedback);
    setTimeout(() => feedback.remove(), 2000);
}